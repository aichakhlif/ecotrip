#include<stdio.h> 
#include<stdlib.h>
#include<SDL/SDL.h>
#include<SDL/SDL_image.h> 
#include <SDL/SDL_ttf.h>
#include <string.h>
#include <time.h>
#include "enigme.h"

int main(int argc , char* args[])
{

char pause;
enigme *E;
int resolu,v;
//char *rep_choisie[4];
affichage(E,v);
SDL_Quit();
pause=getchar();
return resolu;
}

